package company.hr;
public class Employee {
	int rollno;
	String name;
	int age;
	public Employee(int rollno,String name,int age){
		this.rollno=rollno;
		this.name=name;
		this.age=age;
	}
	public void display() {
		System.out.println("Roll No: "+rollno);
		System.out.println("Name: "+name);
		System.out.println("Age: "+age);
	}
}
