package Java;

class calculator{
	void add(int a,int b) {
		System.out.println(a+b);
	}
	void add(int a,int b,int c) {
		System.out.println(a+b+c);
	}
	void add(double a,double b) {
		System.out.println(a+b);
	}
}
public class Exercise2 {
	public static void main(String args[]) {
		calculator cal=new calculator();
		cal.add(10,20);
		cal.add(10,20,30);
		cal.add(1.9876,2.2345678);
	}
}
