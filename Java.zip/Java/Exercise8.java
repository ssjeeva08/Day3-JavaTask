package Java;
interface College{
	String collegeName="KCE";
	static void  displayCollege() {
		System.out.println("College Name:"+collegeName);
	}
}
class Students implements College{
	int rollno;
	String name;
	Students(int rollno,String name){
		this.rollno=rollno;
		this.name=name;
	}
	void display() {
		System.out.println("Roll No:"+rollno);
		System.out.println("Name:"+name);

	}
}
public class Exercise8 {
	public static void main(String args[]) {
		College.displayCollege();
		Students s=new Students(101,"Jeeva");
		s.display();
	}
}
