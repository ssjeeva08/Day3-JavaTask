package Java;
abstract class BankAccount{
	abstract void calculateInterest();
	void displayBankName() {
		System.out.println("SBI Bank");
	}
}
class SavingsAccount extends BankAccount{
	@Override
	void calculateInterest() {
		System.out.println("Savings Interest: 5%");
	}
}
class CurrentAccount extends BankAccount{
	@Override
	void calculateInterest() {
		System.out.println("Current Interest: 3%");
	}
}
public class Exercise5 {
	public static void main(String args[]) {
		SavingsAccount sa=new SavingsAccount();
		sa.displayBankName();
		sa.calculateInterest();
		
		CurrentAccount ca=new CurrentAccount();
		ca.displayBankName();
		ca.calculateInterest();
	}
}
