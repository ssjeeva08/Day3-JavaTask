package Java;

abstract class Persons {

    String name;

    Persons(String name) {
        this.name = name;
    }

    abstract void displayDetails();
}

interface SalaryCalculation {
    void calculateSalary();
}

class Employee extends Persons implements SalaryCalculation {

    double salary;

    Employee(String name, double salary) {
        super(name);
        this.salary = salary;
    }

    @Override
    void displayDetails() {
        System.out.println("Name: " + name);
    }

    @Override
    public void calculateSalary() {
        System.out.println("Salary: " + salary);
    }
}

public class Exercise10 {
    public static void main(String[] args) {

        Employee emp = new Employee("Jeeva", 35000);

        emp.displayDetails();
        emp.calculateSalary();
    }
}