package Java;
class Person{
	String name;
	int age;
	Person(String name,int age){
		this.name=name;
		this.age=age;
	}
}
class Student extends Person{
	int rollno;
	String department;
	Student(String name,int age,int rollno,String department){
		super(name,age);
		this.rollno=rollno;
		this.department=department;
	}
	
	void display() {
		System.out.println("Name: "+name);
		System.out.println("Age: "+age);
		System.out.println("Roll No: "+rollno);
		System.out.println("Department: "+department);
	}
}
public class Exercise4 {
	public static void main(String a[]) {
		Student stud=new Student("Arul",34,101,"IT");
		stud.display();
	}

}
