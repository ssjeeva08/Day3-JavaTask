package Java;

interface Payment{
	void makePayment(double amount);
}
class UPIPayment implements Payment{
	@Override
	public void makePayment(double amount) {
		System.out.println("UPI Payment mode: "+amount);
	}
}
class CardPayment implements Payment{
	@Override
	public void makePayment(double amount) {
		System.out.println("Card Payment mode: "+amount);
	}
}
public class Exercise6 {
	public static void main(String args[]) {
		UPIPayment pay=new UPIPayment();
		pay.makePayment(5000);
		CardPayment cp=new CardPayment();
		cp.makePayment(7000);
			
	}
}
