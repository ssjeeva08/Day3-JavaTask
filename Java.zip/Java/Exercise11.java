package Java;
import java.util.*;
public class Exercise11 {
	public static void main(String args[]) {
		String name = " arul antran vijay ";
		String email = "arul@company.com";
		String department = "Computer Science";
		System.out.println(name.trim());
		System.out.println(name.toUpperCase());
		System.out.println(name.toLowerCase());
		
		System.out.println("Count: "+name.trim().length());
		
		if(email.contains("@company.com")) {
			System.out.println("Valid email");
		}else {
			System.out.println("Invalid email");
		}
		if(name.trim().toUpperCase().startsWith("A")) {
			System.out.println(name);
		}else {
			System.out.println("Name doesnot startswith 'A'.");			
		}
		System.out.println("Occurence of a: "+name.indexOf('a'));		
		System.out.println(name.trim().replace(" ", "_"));
		System.out.println(name.trim().substring(0, 4));
		String dept = "Computer Science";

		if(department.equals(dept)) {
		    System.out.println("Departments are same");
		} else {
		    System.out.println("Departments are different");
		}
	}
}
