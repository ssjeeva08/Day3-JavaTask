package Java;
import java.util.*;
class calculateSalary{
	void salary(){
		System.out.println("Salary calculation");
	}
}
class FullTimeEmployee extends calculateSalary{
	@Override
	void salary() {
			System.out.println("Full Time salary=30000");
		}
}
class PartTimeEmployee extends calculateSalary{
	@Override
	void salary() {
		System.out.println("Full Time salary=30000");
	}
}
public class Exercise3 {
	public static void main(String a[]) {
		FullTimeEmployee f = new FullTimeEmployee();
        PartTimeEmployee p = new PartTimeEmployee();
        calculateSalary calsal=new calculateSalary();
        calsal.salary();
        f.salary();
        p.salary();
	}
}
