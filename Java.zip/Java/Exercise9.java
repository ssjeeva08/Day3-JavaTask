package Java;
class Employees{
	int employeeId;
	String employeeName;
	double salary;
	
	Employees(int employeeId,String employeeName,double salary){
		this.employeeId=employeeId;
		this.employeeName=employeeName;
		this.salary=salary;
	}
	void display() {
		System.out.println("Employee ID: " + employeeId);
        System.out.println("Employee Name: " + employeeName);
        System.out.println("Salary: " + salary);
        System.out.println();
	}
}
public class Exercise9 {
	public static void main(String args[]) {
		Employees emp[]=new Employees[5];
		 emp[0] = new Employees(101, "Arul", 25000);
	     emp[1] = new Employees(102, "Jeeva", 35000);
	     emp[2] = new Employees(103, "John", 40000);
	     emp[3] = new Employees(104, "Ravi", 28000);
	     emp[4] = new Employees(105, "Kumar", 50000);
	     System.out.println("Employees with salary >30000");
	     for(int i=0;i<emp.length;i++) {
	    	 if(emp[i].salary >30000) {
	    		 emp[i].display();
	    	 }
	     }
	}
	
}
