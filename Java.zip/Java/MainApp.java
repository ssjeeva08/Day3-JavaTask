package Java;
import company.hr.Employee;
public class MainApp {
	public static void main(String args[]) {
		Employee emp=new Employee(101,"Jeeva",34);
		emp.display();
	}
}

