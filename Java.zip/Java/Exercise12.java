package Java;

public class Exercise12 {
	public static void main(String args[]) {
		StringBuffer username=new StringBuffer("JavaUser");
		System.out.println("Username: " +username);
		username.append("123");
		System.out.println("Adding 123: " +username);
		username.insert(4, "Pro");
		System.out.println("Adding Pro after Java: " +username);
		username.replace(7, 11, "Developer");
		System.out.println("Replacing User with Developer: " +username);
		username.delete(16, 19);
		System.out.println("Deleting last three characters: " +username);
		username.reverse();
		System.out.println("Reversing the username: " +username);
		System.out.println("Count: " +username.length());
		System.out.println("Character at index 2: " +username.charAt(2));
		System.out.println("Current storage capacity: " +username.capacity());
		username.setCharAt(0,'X');
		System.out.println("Changing the first letter into 'X': "+username);
		String user=username.toString();
		System.out.println("COnverting StringBuffer into String: "+username);
		
	}
}
